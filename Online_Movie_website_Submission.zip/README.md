# Online Movie Streaming Platform (CineVerse)

A massive 50K+ LOC enterprise-grade Netflix clone featuring a Next.js frontend, Django backend, React Native mobile app, React Admin CMS, and FastAPI Microservices.

## Dependencies
- Node.js (v18+)
- Python (3.11+)
- PostgreSQL (or default SQLite)
- FFmpeg (for video encoding)

## Installation

Clone the repository and install all dependencies:
```bash
# Frontend
cd frontend
npm install

# Backend
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate

# Microservices
cd services/recommendation_engine
pip install -r requirements.txt
```

## Build
To build the frontend and mobile apps for production:
```bash
# Frontend Next.js build
cd frontend
npm run build

# Mobile Expo build
cd mobile
npx expo export
```

## Run
To run the entire suite locally in development mode:
```bash
# Or use the Makefile
make start

# Start the frontend
cd frontend && npm run dev

# Start the backend
cd backend && python manage.py runserver
```

## Usage
Navigate to `http://localhost:3000` to access the main web application.
Navigate to `http://localhost:8000/api/` for the Django REST API.
Navigate to `http://localhost:8002` for the FastAPI Recommendation Engine.
